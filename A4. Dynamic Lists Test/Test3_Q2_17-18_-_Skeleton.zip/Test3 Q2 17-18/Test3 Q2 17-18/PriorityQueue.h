#ifndef PRIORITY_QUEUE_H
#define PRIORITY_QUEUE_H

#include <cassert>

template<class T>
class PriorityQueue
{
public:

	PriorityQueue() :
		_front(nullptr),
		_numElems(0)
	{ }

	~PriorityQueue()
	{
		clear();
	}

	unsigned int size() const
	{
		return _numElems;
	}

	bool empty() const
	{
		return _numElems == 0;
	}

	T &front()
	{
		assert(_numElems > 0 && "Cannot obtain the front of an empty queue");
		return _front->value;
	}

	const T &front() const
	{
		assert(_numElems > 0 && "Cannot obtain the front of an empty queue");
		return _front->value;
	}

	void enqueue(const T &value, int priority)
	{
		// TODO
	}

	void dequeue()
	{
		assert(_numElems > 0 && "Cannot dequeue from an empty queue");

		Node *newFront = _front->next;
		delete _front;
		_front = newFront;
		_numElems--;
	}

	void clear()
	{
		while (!empty())
		{
			dequeue();
		}
	}

private:

	struct Node
	{
		T value;
		int priority;
		Node *next;
	};

	Node *_front;
	unsigned int _numElems;
};

#endif // PRIORITY_QUEUE_H
